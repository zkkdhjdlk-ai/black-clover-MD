>𝗖𝗿𝗲𝗮𝗱𝗼𝗿: sinombre913 y thecarlos19 


## `blackclover` 
<img src="https://readme-typing-svg.herokuapp.com/?font=mono&size=30&duration=4000&color=FF0000&center=falso&vCenter=falso&lines=blackclover+;thecarlos19+𝐎𝐟𝐢𝐜𝐢𝐚𝐥+𝐂𝐫𝐞𝐚𝐝𝐨𝐫;1000+𝘊𝘰𝘮𝘢𝘯𝘥𝘰𝘴;blackclover+✰✰✰✰✰">      
</p>
<img src="https://acegif.com/wp-content/gif/outerspace-51.gif" width="400" height="230"/>
</p>
------------------

black clover el mejor bot 🤖

------------------

### `🤖 𝑩𝒐𝒕 𝑶𝒇𝒊𝒄𝒊𝒂𝒍🤖`

<a href="https://api.whatsapp.com/send/?phone=5217971278937&text=/estado&type=phone_number&app_absent=0" target="blank"><img src="https://img.shields.io/badge/Nigromante-25D366?style=for-the-badge&logo=whatsapp&logoColor=white" />

 > NO SPAMEAR COMANDOS



### `𝑪𝒐𝒏𝒇𝒊𝒈𝒖𝒓𝒂𝒄𝒊𝒐𝒏`
- 𝐂𝐥𝐨𝐧𝐚𝐫 𝐑𝐞𝐩𝐨 : [Aqui](https://github.com/bayhackplis1/Black-Clover/fork)

  
### `𝑰𝒏𝒔𝒕𝒂𝒍𝒂𝒓𝒍𝒐 𝑷𝒐𝒓 𝑲𝒐𝒚𝒆𝒃`

[![Deploy to Koyeb](https://www.koyeb.com/static/images/deploy/button.svg)](https://app.koyeb.com/deploy?type=git&repository=https://github.com/sinombre913/NigromanteBot_v2-MD&branch=master&name=NigromanteBot_v2-MD)
  
### `𝑰𝒏𝒔𝒕𝒂𝒍𝒂𝒓 𝑷𝒐𝒓 𝑹𝒆𝒑𝒍𝒊𝒕`

[![Run Repl.it](https://repl.it/badge/github/sinombre913/NigromanteBot_v2-MD)](https://replit/github/sinombre913/NigromanteBot_v2-MD) 
  
### `𝑰𝒏𝒔𝒕𝒂𝒍𝒂𝒓 𝑷𝒐𝒓 𝑹𝒆𝒏𝒅𝒆𝒓`

[![Deploy to Render](https://render.com/images/deploy-to-render-button.svg)](https://dashboard.render.com/blueprint/new?repo=https%3A%2F%2Fgithub.com%2sinombre913%2FNigromanteBot_v2-MD) 

### `𝑰𝒏𝒔𝒕𝒂𝒍𝒂𝒄𝒊𝒐𝒏 𝑷𝒐𝒓 𝑪𝒐𝒅𝒆 𝑺𝒑𝒂𝒄𝒆`

[`CREAR SERVIDOR`](https://github.com/codespaces/new?skip_quickstart=true&machine=basicLinux32gb&repo=733291595&ref=main&geo=UsEast)
***
[`Instalar termux clic aqui`](https://www.mediafire.com/file/3hsvi3xkpq3a64o/termux_118.apk/file)

### `𝑰𝒏𝒔𝒕𝒂𝒍𝒂𝒄𝒊𝒐𝒏 𝑨𝒖𝒕𝒐𝒎𝒂𝒕𝒊𝒄𝒂 𝑽𝒊𝒂 𝑻𝒆𝒓𝒎𝒖𝒙`
```bash
termux-setup-storage
```

```bash
apt update -y && yes | apt upgrade && pkg install -y bash wget mpv && wget -O - https://raw.githubusercontent.com/sinombre913/NigromanteBot_v2-MD/master/Nigromante.sh | bash
```

### `𝑰𝒏𝒔𝒕𝒂𝒍𝒂𝒄𝒊𝒐𝒏 𝑷𝒐𝒓 𝑻𝒆𝒓𝒎𝒖𝒙 𝑴𝒂𝒏𝒖𝒂𝒍` 
- ESCRIBE LOS SIGUIENTES COMANDOS UNO POR UNO:
```bash
cd && termux-setup-storage
```

```bash
apt-get update -y && apt-get upgrade -y
```

```bash
pkg install -y git nodejs ffmpeg imagemagick && pkg install yarn 
```

```bash
git clone https://github.com/bayhackplis1/Black-Clover && cd blackclover 
```

```bash
yarn install
```

```bash
npm install
```

```bash
npm update
```

```bash
npm start
```

### `𝑨𝒄𝒕𝒊𝒗𝒂𝒓 𝑬𝒍 𝑩𝒐𝒕 𝑺𝒊 𝑺𝒆 𝑨𝒑𝒂𝒈𝒂 𝑽𝒊𝒂 𝑺𝒆𝒓𝒗𝒊𝒅𝒐𝒓𝒆𝒔`
```bash
ESCRIBE LOS SIGUIENTES COMANDOS UNO POR UNO:
> cd 
> cd blackclover 
> npm start
```

### `𝑷𝒆𝒅𝒊𝒓 𝑶𝒕𝒓𝒐 𝑸𝒓 𝑷𝒐𝒓 𝑻𝒆𝒓𝒎𝒖𝒙` 
```bash
ESCRIBE LOS SIGUIENTES COMANDOS UNO POR UNO:
> cd 
> rm -rf Session
> npm start
```


 ### `𝑫𝒖𝒅𝒂 𝑫𝒆𝒍 𝑩𝒐𝒕? 𝑬𝒔𝒄𝒓𝒊𝒃𝒆𝒎𝒆`
<a href="http://wa.me/5215544876071" target="blank"><img src="https://img.shields.io/badge/Creador-25D366?style=for-the-badge&logo=whatsapp&logoColor=white" />

### `𝑨𝒔𝒊𝒔𝒕𝒆𝒏𝒄𝒊𝒂`
<a href="http://wa.me/5215544876071" target="blank"><img src="https://img.shields.io/badge/Asistencia-25D366?style=for-the-badge&logo=whatsapp&logoColor=white" />


## `𝑷𝒓𝒐𝒑𝒊𝒆𝒕𝒂𝒓𝒊𝒐 𝑫𝒆𝒍 𝑩𝒐𝒕` 
<a href="https://github.com/thecarlos19"><img src="https://github.com/thecarlos19.png" width="250" height="250" alt="thecarlos19"/></a>