var handler = async (m, { conn, command, text }) => {

if (!text) return conn.reply(m.chat, '🚩 *Escribe el nombre de dos personas para calcular su amor*', m, rcanal, )
let [text1, ...text2] = text.split(' ')

text2 = (text2 || []).join(' ')
if (!text2) return conn.reply(m.chat, `🚩 *Escribe el nombre de la segunda persona*`, m, rcanal, )
let love = `❤️ *${text1}* tu oportunidad de enamorarte de *${text2}* es de ${Math.floor(Math.random() * 100)}% 👩🏻‍❤️‍👨🏻`

m.reply(love, null, { mentions: conn.parseMention(love) })

}
handler.help = ['ship', 'love']
handler.tags = ['fun']
handler.command = ['ship', 'love']

handler.register = true

export default handler