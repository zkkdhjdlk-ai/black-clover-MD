const handler = async (m, {conn}) => {
  m.reply(global.ComprarBot);
};
handler.command ='comprarbot',/^(ComprarBot|Comprar|comprar|ComprarBot)$/i;
export default handler;

global.ComprarBot = `
〔 *BLACK CLOVER- BOT* 〕

*BOT PARA GRUPO* :
> wa.me/527971006556

*BOT PERZONALIZADO* :
> wa.me/525544876071
`;